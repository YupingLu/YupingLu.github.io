import { RouteRecordRaw } from 'vue-router';
import { Layout } from '@/router/constant';
import { SettingOutlined } from '@vicons/antd';
import { renderIcon } from '@/utils/index';

/**
 * @param name Route name, must be set, and cannot be duplicated
 * @param meta Routing meta information (extended information)
 * @param redirect Redirection address, when accessing this route, it will be redirected
 * @param meta.disabled Disable the entire menu
 * @param meta.title Menu name
 * @param meta.icon Menu icon
 * @param meta.keepAlive Cache the route
 * @param meta.sort Smallest first
 * */
const routes: Array<RouteRecordRaw> = [
  {
    path: '/setting',
    name: 'Setting',
    redirect: '/setting/account',
    component: Layout,
    meta: {
      title: 'Setting',
      icon: renderIcon(SettingOutlined),
      sort: 5,
    },
    children: [
      {
        path: 'account',
        name: 'setting-account',
        meta: {
          title: 'Personal Setting',
        },
        component: () => import('@/views/setting/account/account.vue'),
      },
      {
        path: 'system',
        name: 'setting-system',
        meta: {
          title: 'System Setting',
        },
        component: () => import('@/views/setting/system/system.vue'),
      },
    ],
  },
];

export default routes;
