import { RouteRecordRaw } from 'vue-router';
import { Layout } from '@/router/constant';
import { CheckCircleOutlined } from '@vicons/antd';
import { renderIcon } from '@/utils/index';

/**
 * @param name Route name, must be set, and cannot be duplicated
 * @param meta Routing meta information (extended information)
 * @param redirect Redirection address, when accessing this route, it will be redirected
 * @param meta.disabled Disable the entire menu
 * @param meta.title Menu name
 * @param meta.icon Menu icon
 * @param meta.keepAlive Cache the route
 * @param meta.sort Smallest first
 * */
const routes: Array<RouteRecordRaw> = [
  {
    path: '/result',
    name: 'Result',
    redirect: '/result/success',
    component: Layout,
    meta: {
      title: 'Result',
      icon: renderIcon(CheckCircleOutlined),
      sort: 4,
    },
    children: [
      {
        path: 'success',
        name: 'result-success',
        meta: {
          title: 'Success',
        },
        component: () => import('@/views/result/success.vue'),
      },
      {
        path: 'fail',
        name: 'result-fail',
        meta: {
          title: 'Failure',
        },
        component: () => import('@/views/result/fail.vue'),
      },
      {
        path: 'info',
        name: 'result-info',
        meta: {
          title: 'Information',
        },
        component: () => import('@/views/result/info.vue'),
      },
    ],
  },
];

export default routes;
