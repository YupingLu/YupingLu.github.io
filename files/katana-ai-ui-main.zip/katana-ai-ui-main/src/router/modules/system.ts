import { RouteRecordRaw } from 'vue-router';
import { Layout } from '@/router/constant';
import { OptionsSharp } from '@vicons/ionicons5';
import { renderIcon } from '@/utils/index';

/**
 * @param name Route name, must be set, and cannot be duplicated
 * @param meta Routing meta information (extended information)
 * @param redirect Redirection address, when accessing this route, it will be redirected
 * @param meta.disabled Disable the entire menu
 * @param meta.title Menu name
 * @param meta.icon Menu icon
 * @param meta.keepAlive Cache the route
 * @param meta.sort Smallest first
 * */
const routes: Array<RouteRecordRaw> = [
  {
    path: '/system',
    name: 'System',
    redirect: '/system/menu',
    component: Layout,
    meta: {
      title: 'System Setting',
      icon: renderIcon(OptionsSharp),
      sort: 1,
    },
    children: [
      {
        path: 'menu',
        name: 'system_menu',
        meta: {
          title: 'Menu Permission Management',
        },
        component: () => import('@/views/system/menu/menu.vue'),
      },
      {
        path: 'role',
        name: 'system_role',
        meta: {
          title: 'Role Permission Management',
        },
        component: () => import('@/views/system/role/role.vue'),
      },
    ],
  },
];

export default routes;
