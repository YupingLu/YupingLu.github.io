/**
 * 全局注册自定义组件 待完善
 * @param app
 */
export function setupCustomComponents() {
  // app.component()
}
