export enum RoleEnum {
  // 管理员
  ADMIN = 'admin',

  // 普通用户
  NORMAL = 'normal',
}
