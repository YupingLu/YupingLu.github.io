export const animates = [
  { value: 'zoom-fade', label: 'Zoom Fade' },
  { value: 'zoom-out', label: 'Zoom Out' },
  { value: 'fade-slide', label: 'Fade Slide' },
  { value: 'fade', label: 'Fade' },
  { value: 'fade-bottom', label: 'Fade Bottom' },
  { value: 'fade-scale', label: 'Fade Scale' },
];
