import MainView from './index.vue';

export { MainView };
