<template>
  <n-grid cols="1" responsive="screen" class="-mt-5">
    <n-grid-item>
      <n-list>
        <n-list-item>
          <template #suffix>
            <n-button type="primary" text>Modify</n-button>
          </template>
          <n-thing title="Account Password">
            <template #description
              ><span class="text-gray-400">Add Phone, Email and Password</span></template
            >
          </n-thing>
        </n-list-item>
        <n-list-item>
          <template #suffix>
            <n-button type="primary" text>Modify</n-button>
          </template>
          <n-thing title="Phone">
            <template #description
              ><span class="text-gray-400">Phone Added: +86189****4877</span></template
            >
          </n-thing>
        </n-list-item>
        <n-list-item>
          <template #suffix>
            <n-button type="primary" text>Setting</n-button>
          </template>
          <n-thing title="Password Questions">
            <template #description
              ><span class="text-gray-400"
                >No password questions found</span
              ></template
            >
          </n-thing>
        </n-list-item>
        <n-list-item>
          <template #suffix>
            <n-button type="primary" text>Modify</n-button>
          </template>
          <n-thing title="Domain">
            <template #description
              ><span class="text-gray-400">https://katanagraph.com/</span></template
            >
          </n-thing>
        </n-list-item>
      </n-list>
    </n-grid-item>
  </n-grid>
</template>

<script lang="ts" setup></script>
