export type ComponentType =
  | 'NInput'
  | 'NInputNumber'
  | 'NSelect'
  | 'NCheckbox'
  | 'NSwitch'
  | 'NDatePicker'
  | 'NTimePicker';
