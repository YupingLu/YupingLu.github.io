import { withInstall } from '@/utils';
import countTo from './CountTo.vue';

export const CountTo = withInstall(countTo);
