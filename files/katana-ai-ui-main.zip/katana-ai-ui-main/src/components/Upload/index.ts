export { default as BasicUpload } from './src/BasicUpload.vue';
