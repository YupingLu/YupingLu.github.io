import LockScreen from './Lockscreen.vue';

export { LockScreen };
