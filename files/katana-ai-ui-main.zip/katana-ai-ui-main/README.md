## Quick Start

- Clone the repo

```bash
git clone git@github.com:KatanaGraph/katana-ai-ui.git
```

- Install

```bash
cd katana-ai-ui

yarn install

```

- Run

```bash
yarn dev
```

Username: admin, Password: 123456
